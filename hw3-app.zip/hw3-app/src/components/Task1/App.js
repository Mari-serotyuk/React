import React from "react";


export default class App extends React.Component {
    state = {
        error: null,
        isLoaded: false,
        albums: []
    }

    componentDidMount() {
        fetch('https://jsonplaceholder.typicode.com/albums')
        .then(res => res.json())
        .then(
            (result) => {
                this.setState({
                    isLoaded: true,
                    albums: result.albums
                });
            },
            (error) => {
                this.setState({
                    isLoaded: true,
                    error
                });
            }
        )
    }

    render() {
        const {error, isLoaded, albums} = this.state;

        if (error) {
            return <div>Error: {error.message}</div>;
        } else if (!isLoaded) {
            return <div>Loading...</div>
        } else {
            return(
                <div>
                    <ul>
                        {albums.map((album) => (
                            <div
                            key={album.id}>
                                {album.title}
                            </div>
                        ))}
                    </ul>
                </div>
            )
        }
                
    }
}